*****************************************************************************
** ChibiOS/RT demo for generict ARM Cortex-M3 processor, kernel only.      **
*****************************************************************************

** TARGET **

The demo runs on any ARM Cortex-M3 processor after changing few constants
in main.c, the defaults are setup for an STM32F1xx.

** Build Procedure **

The demo has been tested by using the free CodeSourcery GCC-based toolchain
and YAGARTO. just modify the TRGT line in the makefile in order to use
different GCC toolchains.
